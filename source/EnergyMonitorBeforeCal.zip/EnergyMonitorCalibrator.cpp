/*
The MIT License (MIT)

Copyright (c) 2016 British Broadcasting Corporation.
This software is provided by Lancaster University by arrangement with the BBC.

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
*/

#include "MicroBitConfig.h"
#include "EnergyMonitorCalibrator.h"
#include "EventModel.h"

EnergyMonitorCalibrator::EnergyMonitorCalibrator(MicroBitCompass& _magnetometer, MicroBitDisplay& _display) : compass(_magnetometer), display(_display)
{
    if (EventModel::defaultEventBus)
    {
        EventModel::defaultEventBus->listen(MICROBIT_ID_ELECTRICAL_POWER, MICROBIT_ELECTRICAL_EVT_CALIBRATE, this, &EnergyMonitorCalibrator::calibrateUX, MESSAGE_BUS_LISTENER_IMMEDIATE);
        EventModel::defaultEventBus->listen(MICROBIT_ID_BUTTON_AB, MICROBIT_BUTTON_EVT_CLICK, this, &EnergyMonitorCalibrator::stopCalibration, MESSAGE_BUS_LISTENER_IMMEDIATE);
    }
}

void EnergyMonitorCalibrator::calibrateUX(MicroBitEvent)
{
    const int TIME_STEP = 100;
    
    int displayBrightness = display.getBrightness();
    int minAmplitude = 2147483647;
    int maxAmplitude = -2147483646;
    int amplitude = 0;
    int strength = 0;
    
    wait_ms(1000); // prevent spikes in magnetic field

    // firstly, we need to take over the display. Ensure all active animations are paused.
    display.stopAnimation();
    display.setBrightness(255); // max brightness

    while(calibrationRunning)
    {
        amplitude = getAmplitude();
        strength = monitor.map(amplitude, minAmplitude, maxAmplitude, 0, 4); // update the strength to 0-4
        
        display.clear();
        
        for(int x = 0; x < 5; x++)
            display.image.setPixelValue(x, 4 - strength, 255); // draw line accross display at current strength
            
        wait_ms(TIME_STEP);
    }

    display.clear();
    display.printAsync(smiley, 0, 0, 0, 1500);
    wait_ms(1000);
    display.clear();

    // retore the display brightness to the level it was at before this function was called.
    display.setBrightness(displayBrightness);
}

void EnergyMonitorCalibrator::stopAnimation()
{
    calibrationRunning = false;
}

bool isCalibrating()
{
    return calibrationRunning;
}